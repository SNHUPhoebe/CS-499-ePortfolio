# Setup the Dash version of Dash (not JupyterDash)
from dash import Dash, dcc, html, dash_table
import dash_leaflet as dl
import plotly.express as px
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from dash.dependencies import Input, Output
from CRUDMongoModule import CRUDMongo
import json

###########################
# Data Manipulation / Model
###########################

# Load configuration from the JSON file
with open('config.json', 'r') as f:
    config = json.load(f)

username = config['username']
password = config['password']
host = config['host']
port = config['port']
database = config['database']
collection = config['collection']

try:
    # Attempt to create an instance of CRUDMongo and connect to MongoDB
    db = CRUDMongo(username, password, host, port, database, collection)
    print("Connected to MongoDB successfully.")

except Exception as e:
    # Handle any exception that occurs during the connection
    print(f"Error occurred while connecting to MongoDB: {e}")

# Fetch data from MongoDB and load into a DataFrame
df = pd.DataFrame.from_records(db.read({}, {"_id": 0}))

###########################
# Dashboard Layout / View
###########################

app = Dash(__name__)

# Base layout structure
layout_content = [
    html.Div(html.H1('SNHU CS-340 Dashboard', style={'text-align': 'center'})),
    html.Hr(),
    dcc.Store(id='stored-data', storage_type='memory'),  # This will store the data in memory (cache strategy)
    # Radio buttons for choosing rescue types
    dcc.RadioItems(
        id='rescue-radio-buttons',
        options=[
            {'label': 'Water Rescue', 'value': 'Water Rescue'},
            {'label': 'Mountain Rescue', 'value': 'Mountain Rescue'},
            {'label': 'Disaster Rescue', 'value': 'Disaster Rescue'},
            {'label': 'Reset', 'value': 'Reset'}
        ],
    )
]

# Check if df is empty
if not df.empty:
    # Add DataTable if DataFrame is not empty
    layout_content.append(
        dash_table.DataTable(
            id='datatable-id',
            columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
            data=df.to_dict('records'),
            editable=False,
            filter_action="native",
            sort_action="native",
            sort_mode="multi",
            column_selectable=False,
            row_selectable="single",
            row_deletable=False,
            selected_columns=[],
            selected_rows=[],
            page_action="native",
            page_current=0,
            page_size=10
        )
    )
else:
    # Add message if DataFrame is empty
    layout_content.append(
        html.H4("No data available to display.")
    )

# Add the remaining layout components
layout_content.extend([
    html.Br(),
    html.Hr(),
    # Graph and Map layout
    html.Div(className='row', style={'display': 'flex'}, children=[
        html.Div(id='graph-id', className='col s12 m6'),
        html.Div(id='map-id', className='col s12 m6')
    ]),
    # Clickable Logo
    html.A([html.Img(src=app.get_asset_url('GS_Logo.png'), style={'height': '7%', 'width': '7%'})],
           href='https://www.snhu.edu'),
    # Unique identifier
    html.H4("Phoebe Johnson SNHU CS-340 MongoDB Authentication")
])

# Set the layout of the app
app.layout = html.Div(layout_content)

##############################
# Interaction Between Components / Controller
##############################

# MongoDB queries for different radio buttons selections
water_rescue = db.read({"$or": [{"breed": {"$regex": "Labrador Retriever"}}, {"breed": {"$regex": "Chesa Bay"}},
                                {"breed": {"$regex": "Newfoundland"}}],
                        "sex_upon_outcome": "Intact Female",
                        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}})

mountain_rescue = db.read({"$or": [{"breed": {"$regex": "German Shepherd"}}, {"breed": {"$regex": "Alaskan Malamute"}},
                                   {"breed": {"$regex": "Old English Sheepdog"}},
                                   {"breed": {"$regex": "Siberian Husky"}}, {"breed": {"$regex": "Rottweiler"}}],
                           "sex_upon_outcome": "Intact Male",
                           "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}})

disaster_rescue = db.read({"$or": [{"breed": {"$regex": "Doberman Pinsch"}}, {"breed": {"$regex": "German Shepherd"}},
                                   {"breed": {"$regex": "Golden Retriever"}}, {"breed": {"$regex": "Bloodhound"}},
                                   {"breed": {"$regex": "Rottweiler"}}],
                           "sex_upon_outcome": "Intact Male",
                           "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}})


# Callback to update data table based on the selected rescue type
@app.callback(
    Output('datatable-id', 'data'),
    Input('rescue-radio-buttons', 'value')
)
def update_chart(choice):
    if choice == 'Water Rescue':
        df = pd.DataFrame.from_records(water_rescue)
    elif choice == 'Mountain Rescue':
        df = pd.DataFrame.from_records(mountain_rescue)
    elif choice == 'Disaster Rescue':
        df = pd.DataFrame.from_records(disaster_rescue)
    else:
        # Default choice: reset to all records
        df = pd.DataFrame.from_records(db.read({}))

    # Cleanup MongoDB '_id' field
    df.drop(columns=['_id'], inplace=True)

    return df.to_dict('records')


# Callback for row selection highlighting
@app.callback(
    Output('datatable-id', 'style_data_conditional'),
    Input('datatable-id', 'selected_columns')
)
def update_styles(selected_columns):
    return [{
        'if': {'column_id': i},
        'background_color': '#D2F3FF'
    } for i in selected_columns]


# Callback for graph update based on data table selection
@app.callback(
    Output('graph-id', "children"),
    [Input('datatable-id', 'derived_viewport_data'),
     Input('rescue-radio-buttons', 'value')]
)
def update_graph(viewData, choice):
    dff = pd.DataFrame.from_dict(viewData)

    return [
        dcc.Graph(
            figure=px.histogram(dff, x=['breed'])
        )
    ]


# Callback for map update based on data table selection
@app.callback(
    Output('map-id', "children"),
    [Input('datatable-id', "derived_virtual_data"),
     Input('datatable-id', "derived_virtual_selected_rows")]
)
def update_map(viewData, index):
    dff = pd.DataFrame.from_dict(viewData)
    if index is None or not index:
        row = 0
    else:
        row = index[0]

    return [
        dl.Map(style={'width': '1000px', 'height': '500px'},
               center=[30.75, -97.48],
               zoom=10,
               children=[
                   dl.TileLayer(id="base-layer-id"),
                   dl.Marker(position=[dff.iloc[row, 13], dff.iloc[row, 14]],
                             children=[
                                 dl.Tooltip(dff.iloc[row, 4]),
                                 dl.Popup([
                                     html.H1("Animal Name"),
                                     html.P(dff.iloc[row, 9])
                                 ])
                             ])
               ])
    ]


# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
