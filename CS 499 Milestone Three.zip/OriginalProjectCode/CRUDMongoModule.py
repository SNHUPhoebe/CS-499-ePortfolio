#!/usr/bin/env python
# coding: utf-8

from pymongo import MongoClient
from bson.objectid import ObjectId

class CRUDMongo(object):
    """ CRUD operations for Animal collection in MongoDB """

    # Takes parameters username and password
    def __init__(self, username, password, host, port, database, collection):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # Connection Variables
        #
        USER = "aacuser"
        PASS = "password"
        # HOST = 'nv-desktop-services.apporto.com'
        # HOST = '127.0.0.1'
        # PORT = 30243
        # DB = 'AAC'
        # COL = 'animals'
        #
        # Initialize Connection
        #
        if username == USER and password == PASS:
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (username,password,host,port))
            self.database = self.client['%s' % (database)]
            self.collection = self.database['%s' % (collection)]
        else:
            raise Exception("Invalid login credentials.")

    # Create method to implement the C in CRUD.
    def create(self, data):
        # Checks to see if data is input
        if data is not None:
            try:
                # tries inserting new document
                self.database.animals.insert_one(data)
                # returns true if successful
                return True
            except Exception as e:
                # Exception thrown, prints error
                print("An exception occurred ::", e)
                # Returns false if unsuccessful
                return False        
        else:
            # Exception thrown if data is not input
            raise Exception("Nothing to save, because data parameter is empty")
            return false

    # Read method to implement the R in CRUD.
    def read(self, data):
        read_list = []
        if data is not None:
            cursor = self.database.animals.find(data)
            for result in cursor:
                read_list.append(result)
        else:
            # Exception thrown if data is not input
            raise Exception("Nothing to read, because a data parameter is empty")
        # returns list of results
        return read_list
      
    # Update method to implement the U in CRUD
    def update(self, lookup_key, lookup_value, new_key, new_value):
        if None not in (lookup_key, lookup_value, new_key, new_value):
            try:
                # tries updating an existing document
                result = self.database.animals.update_many({lookup_key: lookup_value}, {"$set": {new_key: new_value}})
                # returns number of modified entries
                return result.modified_count
            except Exception as e:
                # Exception thrown, prints error
                print("An exception occurred ::", e)
                # Returns 0 for zero modified entries
                return 0
        else:
            # Exception thrown if data is not input
            raise Exception("Nothing to update, because a data parameter is empty")
            return false 
        
    # Delete method to implement the D in CRUD
    def delete(self, key, value):
        if None not in (key, value):
            try:
                # tries deleting an existing document
                result = self.database.animals.delete_many({key: value})
                # returns number of deleted entries
                return result.deleted_count
            except Exception as e:
                # Exception thrown, prints error
                print("An exception occurred ::", e)
                # Returns 0 for zero deleted entries
                return 0
        else:
            # Exception thrown if data is not input
            raise Exception("Nothing to delete, because a data parameter is empty")
            return false 