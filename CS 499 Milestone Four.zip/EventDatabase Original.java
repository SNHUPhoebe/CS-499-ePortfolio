package com.snhu.cs_360_final_project.Databases;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.time.YearMonth;
import java.util.Calendar;
import java.util.Date;

public class EventDatabase extends SQLiteOpenHelper
{
    private Context context;

    private static final String DATABASE_NAME = "events.db";
    private static final int VERSION = 1;

    public EventDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    private static final class EventTable {
        private static final String TABLE_NAME = "events",
                COL_ID = "_id",
                COL_TITLE = "title",
                COL_LOCATION = "location",
                COL_DESCRIPTION = "description",
                COL_DAY = "day",
                COL_MONTH = "month",
                COL_YEAR = "year",
                COL_HOUR = "hour",
                COL_MINUTE = "minute";
    }

    //todo add integer user id for specific login person data

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String query = "CREATE TABLE " + EventTable.TABLE_NAME +
                " (" + EventTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EventTable.COL_TITLE + " TEXT, " +
                EventTable.COL_LOCATION + " TEXT, " +
                EventTable.COL_DESCRIPTION + " TEXT, " +
                EventTable.COL_YEAR + " INTEGER, " +
                EventTable.COL_MONTH + " INTEGER, " +
                EventTable.COL_DAY + " INTEGER, " +
                EventTable.COL_HOUR + " INTEGER, " +
                EventTable.COL_MINUTE + " INTEGER)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + EventTable.TABLE_NAME);
        onCreate(db);
    }

    public void addEvent(String title, String location, String description, Date date) {
        SQLiteDatabase db = this.getWritableDatabase();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        ContentValues values = new ContentValues();
        values.put(EventTable.COL_TITLE, title);
        values.put(EventTable.COL_LOCATION, location);
        values.put(EventTable.COL_DESCRIPTION, description);
        System.out.println("col day: " + calendar.get(Calendar.DAY_OF_MONTH));
        values.put(EventTable.COL_DAY, (Integer) calendar.get(Calendar.DAY_OF_MONTH));
        values.put(EventTable.COL_MONTH, calendar.get(Calendar.MONTH));
        values.put(EventTable.COL_YEAR, calendar.get(Calendar.YEAR));
        values.put(EventTable.COL_HOUR, calendar.get(Calendar.HOUR));
        values.put(EventTable.COL_MINUTE, calendar.get(Calendar.MINUTE));

        long result = db.insert(EventTable.TABLE_NAME, null, values);
        if(result == -1)
        {
            Toast.makeText(context, "Add Event Failed", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(context, "Add Event " + title + " Success", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("Range")
    public Cursor readAllData()
    {
        String query = "SELECT * FROM " + EventTable.TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null)
        {
            cursor = db.rawQuery(query, null);
            if(cursor.moveToFirst())
            {
                System.out.println("get int: " + cursor.getInt(cursor.getColumnIndex(EventTable.COL_DAY)));
            }

        }
        return cursor;
    }

    /**
     * updates event given string value
     * @param id event id
     * @param col number of the category of the event
     * @param str item to be updated
     * @return true if successfully updated
     */
    public boolean updateEvent(long id, String col, String str)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(col, str);

        int rowsUpdated = db.update(EventTable.TABLE_NAME, values, "_id = ?",
                new String[] { Float.toString(id) });
        return rowsUpdated > 0;
    }

    /**
     * updates event given int value
     * @param id event id
     * @param col number of the category of the event
     * @param dateItem item to be updated
     * @return true if successfully updated
     */
    public boolean updateEvent(long id, String col, int dateItem)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(col, dateItem);

        int rowsUpdated = db.update(EventTable.TABLE_NAME, values, "_id = ?",
                new String[] { Float.toString(id) });
        return rowsUpdated > 0;
    }

    public boolean deleteMovie(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(EventTable.TABLE_NAME, EventTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });
        return rowsDeleted > 0;
    }

    /**
     * Remove all info from database.
     */
    public void removeAll()
    {
        // db.delete(String tableName, String whereClause, String[] whereArgs);
        SQLiteDatabase db = getWritableDatabase(); // helper is object extends SQLiteOpenHelper
        db.delete(EventTable.TABLE_NAME, null, null);
    }
}
