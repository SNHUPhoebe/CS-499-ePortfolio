package com.snhu.cs_360_final_project.Databases;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;

public class EventDatabase {
    private final Context context;
    private static final String DB_URL = "jdbc:mysql://<your-server>:<port>/<your-database>";
    private static final String DB_USER = "<your-username>";
    private static final String DB_PASSWORD = "<your-password>";

    /**
     * Constructor
     * @param context of the application
     */
    public EventDatabase(Context context) {
        this.context = context;
        createTableIfNotExists();
    }

    /**
     * Get MySQL connection
     * @return connection
     * @throws SQLException if an exception was thrown
     */
    private Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Make sure MySQL JDBC driver is added as a dependency
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (Exception e) {
            Log.e("EventDatabase", "Error establishing connection", e);
            return null;
        }
    }

    /**
     * Creates a table if it doesnt exist
     */
    private void createTableIfNotExists() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS events (" +
                "_id INT AUTO_INCREMENT PRIMARY KEY, " +
                "title VARCHAR(100), " +
                "location VARCHAR(100), " +
                "description TEXT, " +
                "day INT, " +
                "month INT, " +
                "year INT, " +
                "hour INT, " +
                "minute INT)";

        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            if (conn != null) {
                stmt.executeUpdate(createTableQuery);
                Log.d("EventDatabase", "Table 'events' created or already exists.");
            }
        } catch (SQLException e) {
            Log.e("EventDatabase", "Error creating table", e);
        }
    }

    /**
     * Sanitizes input to avoid SQL injection
     * @param input the raw input string
     * @return sanitized input
     */
    private String sanitizeInput(String input) {
        // Remove HTML tags
        input = input.replaceAll("<[^>]*>", "");
        // Escape single quotes
        input = input.replace("'", "''");
        return input;
    }

    /**
     * Adds an event to the the database
     * @param title of the event
     * @param location of the event
     * @param description of the event
     * @param date of the event
     */
    public void addEvent(String title, String location, String description, Date date) {
        // Trim whitespace
        title = title.trim();
        location = location.trim();
        description = description.trim();

        // Validate input
        if (title.isEmpty()) {
            Toast.makeText(context, "Title cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (title.length() > 100 || description.length() > 500) {
            Toast.makeText(context, "Title or Description is too long", Toast.LENGTH_SHORT).show();
            return;
        }

        // Sanitization of input
        title = sanitizeInput(title);
        location = sanitizeInput(location);
        description = sanitizeInput(description);

        try (Connection conn = getConnection()) {
            if (conn != null) {
                String query = "INSERT INTO events (title, location, description, day, month, year, hour, minute) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(date);

                    stmt.setString(1, title);
                    stmt.setString(2, location);
                    stmt.setString(3, description);
                    stmt.setInt(4, calendar.get(Calendar.DAY_OF_MONTH));
                    stmt.setInt(5, calendar.get(Calendar.MONTH));
                    stmt.setInt(6, calendar.get(Calendar.YEAR));
                    stmt.setInt(7, calendar.get(Calendar.HOUR_OF_DAY));
                    stmt.setInt(8, calendar.get(Calendar.MINUTE));

                    int result = stmt.executeUpdate();
                    if (result == 0) {
                        Toast.makeText(context, "Add Event Failed", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, "Add Event " + title + " Success", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        } catch (SQLException e) {
            Log.e("EventDatabase", "Error inserting event", e);
        }
    }

    /**
     * Reads all the data of from the event table
     * @return cursor with all events
     */
    public ResultSet readAllData() {
        String query = "SELECT * FROM events";
        try (Connection conn = getConnection()) {
            assert conn != null;
            try (Statement stmt = conn.createStatement()) {
                return stmt.executeQuery(query);
            }
        } catch (SQLException e) {
            Log.e("EventDatabase", "Error reading data", e);
        }
        return null;
    }

    /**
     * updates event given string value
     * @param id event id
     * @param col number of the category of the event
     * @param str item to be updated
     * @return true if successfully updated
     */
    public boolean updateEvent(long id, String col, String str) {
        try (Connection conn = getConnection()) {
            if (conn != null) {
                String query = "UPDATE events SET " + col + " = ? WHERE _id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setString(1, str);
                    stmt.setLong(2, id);

                    int rowsUpdated = stmt.executeUpdate();
                    return rowsUpdated > 0;
                }
            }
        } catch (SQLException e) {
            Log.e("EventDatabase", "Error updating event", e);
        }
        return false;
    }

    /**
     * Deletes event from the database
     * @param id of event to delete
     * @return if event successfully deleted
     */
    public boolean deleteEvent(long id) {
        try (Connection conn = getConnection()) {
            if (conn != null) {
                String query = "DELETE FROM events WHERE _id = ?";
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.setLong(1, id);
                    int rowsDeleted = stmt.executeUpdate();
                    return rowsDeleted > 0;
                }
            }
        } catch (SQLException e) {
            Log.e("EventDatabase", "Error deleting event", e);
        }
        return false;
    }

    /**
     * Remove all info from database.
     */
    public void removeAll() {
        try (Connection conn = getConnection()) {
            if (conn != null) {
                String query = "DELETE FROM events";
                try (PreparedStatement stmt = conn.prepareStatement(query)) {
                    stmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            Log.e("EventDatabase", "Error removing all events", e);
        }
    }
}
